package uoc.appdroid8;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

}
