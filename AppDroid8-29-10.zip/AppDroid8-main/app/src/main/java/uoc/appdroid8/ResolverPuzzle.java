package uoc.appdroid8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ResolverPuzzle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resolver_puzzle);
    }
}