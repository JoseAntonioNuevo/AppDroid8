package uoc.appdroid8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import uoc.appdroid8.entidades.ConexionSQLiteHelper;
import uoc.appdroid8.utilidades.Utilidades;

public class MainActivity extends AppCompatActivity  {
    private Button buttonPuzzle;
    WebView miVisorWeb;
    //URL provisional:
    String url = "https://www.puzzlepassion.com/top-10-trucos-y-consejos-para-montar-puzzles-con-exito";
    //String url = "https://sites.google.com/d/1ERbNSvMNOVMD2gLeGbo27BX8GOez_Av5/p/1kShnFwb7oE0mlawvpLsTgcLg1jBDn6lj/edit";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buttonPuzzle = (Button) findViewById(R.id.btnSecuenciaImagen);
        buttonPuzzle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openResolverPuzzle();
            }
        });

        // puntuacion= (EditText) findViewById(R.id.puntuacion_text);

        //Conexión a a base de datos
        ConexionSQLiteHelper conn = new ConexionSQLiteHelper(this, "bd_appdroid8", null, 1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //Boton para ir atras en toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        registrarPuntuacion();

        Spinner spinner = findViewById(R.id.spinnerImagenes);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                onClickcambiaImagen(v);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    public void openResolverPuzzle(){
        Intent intent = new Intent(this, ResolverPuzzle.class);
        startActivity(intent);
    }


    //Boton cambia de imagen
    public void onClickcambiaImagen(View v) {
        Spinner imagen = (Spinner) findViewById(R.id.spinnerImagenes);
        ImageView imageView6 = (ImageView)  findViewById(R.id.imageView6);
        String img = String.valueOf(imagen.getSelectedItem());
        if (img.equals("The force awakens")) {
             imageView6.setImageResource(R.drawable.imagen1);
        } else if (img.equals("The last jedy")) {
            imageView6.setImageResource(R.drawable.imagen2);
        } else if (img.equals("Revenge of the sith")) {
            imageView6.setImageResource(R.drawable.imagen3);
        } else {
            imageView6.setImageResource(R.drawable.imagen4);
        }
    }

    //Boton cambia de imagen
    public void onClickHacerPuzzle(View v) {
        Spinner imagen = (Spinner) findViewById(R.id.spinnerImagenes);
        ImageView imageView6 = (ImageView)  findViewById(R.id.imageView6);
        String img = String.valueOf(imagen.getSelectedItem());
        if (img.equals("The force awakens")) {
            imageView6.setImageResource(R.drawable.imagen1);
        } else if (img.equals("The last jedy")) {
            imageView6.setImageResource(R.drawable.imagen2);
        } else if (img.equals("Revenge of the sith")) {
            imageView6.setImageResource(R.drawable.imagen3);
        } else {
            imageView6.setImageResource(R.drawable.imagen4);
        }
    }

    //Abrir web
    public void helpView(View v){
        miVisorWeb = (WebView) findViewById(R.id.visorWeb);
        final WebSettings ajustesVisorWeb = miVisorWeb.getSettings();
        ajustesVisorWeb.setJavaScriptEnabled(true);
        miVisorWeb.loadUrl(url);
    }

    //Impedir que el botón Atrás cierre la aplicación
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        WebView miVisorWeb;
        miVisorWeb = (WebView) findViewById(R.id.visorWeb);
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (miVisorWeb.canGoBack()) {
                        miVisorWeb.goBack();
                    } else {
                        finish();
                    }
                    return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    public class MyActivity extends AppCompatActivity {
        // ...
    }

    //Registrar puntuación en base de datos
    public void onclick(View view){
        registrarPuntuacion();
    }

    private void registrarPuntuacion(){
        ConexionSQLiteHelper conn = new ConexionSQLiteHelper(this, "bd_appdroid8", null, 1);
        SQLiteDatabase db= conn.getWritableDatabase();

        ContentValues values = new ContentValues();
       // values.put(Utilidades.CAMPO_ID,puntuacion.getText().toString());
        values.put(Utilidades.CAMPO_ID,200);
        Long idResultante=db.insert(Utilidades.TABLA_PUNTUACIONES,Utilidades.CAMPO_PUNTUACION,values);

        Toast.makeText(getApplicationContext(),"Id Registro: "+idResultante,Toast.LENGTH_SHORT).show();

    }

}